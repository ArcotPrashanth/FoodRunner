package com.internshala.foodrunner.model

data class RestItem (
    val id : Int,
    val name: String,
    val costForOne : Int,
    val restaurant_id : Int
){
}